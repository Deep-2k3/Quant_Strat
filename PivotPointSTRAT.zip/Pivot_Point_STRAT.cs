#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private PTI.internals.PPG_1_For_PPStrat[] cachePPG_1_For_PPStrat;

		
		public PTI.internals.PPG_1_For_PPStrat PPG_1_For_PPStrat(int period1, int period2, double atrMult, double pctAbove, double pctBelow)
		{
			return PPG_1_For_PPStrat(Input, period1, period2, atrMult, pctAbove, pctBelow);
		}


		
		public PTI.internals.PPG_1_For_PPStrat PPG_1_For_PPStrat(ISeries<double> input, int period1, int period2, double atrMult, double pctAbove, double pctBelow)
		{
			if (cachePPG_1_For_PPStrat != null)
				for (int idx = 0; idx < cachePPG_1_For_PPStrat.Length; idx++)
					if (cachePPG_1_For_PPStrat[idx].Period1 == period1 && cachePPG_1_For_PPStrat[idx].Period2 == period2 && cachePPG_1_For_PPStrat[idx].atrMult == atrMult && cachePPG_1_For_PPStrat[idx].PctAbove == pctAbove && cachePPG_1_For_PPStrat[idx].PctBelow == pctBelow && cachePPG_1_For_PPStrat[idx].EqualsInput(input))
						return cachePPG_1_For_PPStrat[idx];
			return CacheIndicator<PTI.internals.PPG_1_For_PPStrat>(new PTI.internals.PPG_1_For_PPStrat(){ Period1 = period1, Period2 = period2, atrMult = atrMult, PctAbove = pctAbove, PctBelow = pctBelow }, input, ref cachePPG_1_For_PPStrat);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.PTI.internals.PPG_1_For_PPStrat PPG_1_For_PPStrat(int period1, int period2, double atrMult, double pctAbove, double pctBelow)
		{
			return indicator.PPG_1_For_PPStrat(Input, period1, period2, atrMult, pctAbove, pctBelow);
		}


		
		public Indicators.PTI.internals.PPG_1_For_PPStrat PPG_1_For_PPStrat(ISeries<double> input , int period1, int period2, double atrMult, double pctAbove, double pctBelow)
		{
			return indicator.PPG_1_For_PPStrat(input, period1, period2, atrMult, pctAbove, pctBelow);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.PTI.internals.PPG_1_For_PPStrat PPG_1_For_PPStrat(int period1, int period2, double atrMult, double pctAbove, double pctBelow)
		{
			return indicator.PPG_1_For_PPStrat(Input, period1, period2, atrMult, pctAbove, pctBelow);
		}


		
		public Indicators.PTI.internals.PPG_1_For_PPStrat PPG_1_For_PPStrat(ISeries<double> input , int period1, int period2, double atrMult, double pctAbove, double pctBelow)
		{
			return indicator.PPG_1_For_PPStrat(input, period1, period2, atrMult, pctAbove, pctBelow);
		}

	}
}

#endregion
